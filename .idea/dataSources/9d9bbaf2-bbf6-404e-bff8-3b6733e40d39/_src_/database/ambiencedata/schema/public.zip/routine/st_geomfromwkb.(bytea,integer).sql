create function st_geomfromwkb(bytea, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT public.ST_SetSRID(public.ST_GeomFromWKB($1), $2)
$$;
