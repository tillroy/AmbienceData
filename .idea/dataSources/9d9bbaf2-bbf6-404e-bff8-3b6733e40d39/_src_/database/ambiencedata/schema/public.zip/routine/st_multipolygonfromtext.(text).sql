create function st_multipolygonfromtext(text) returns geometry
LANGUAGE SQL
AS $$
SELECT public.ST_MPolyFromText($1)
$$;
