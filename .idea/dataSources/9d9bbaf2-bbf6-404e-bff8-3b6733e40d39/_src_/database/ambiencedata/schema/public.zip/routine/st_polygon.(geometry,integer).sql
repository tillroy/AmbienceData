create function st_polygon(geometry, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT public.ST_SetSRID(public.ST_MakePolygon($1), $2)

$$;
