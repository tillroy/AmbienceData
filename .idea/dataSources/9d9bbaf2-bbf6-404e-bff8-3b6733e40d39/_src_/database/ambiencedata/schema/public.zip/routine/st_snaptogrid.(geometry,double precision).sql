create function st_snaptogrid(geometry, double precision) returns geometry
LANGUAGE SQL
AS $$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $2)
$$;
