create function dropgeometrycolumn(table_name character varying, column_name character varying) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	ret text;
BEGIN
	SELECT DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$$;
