create function st_valuecount(rast raster, nband integer, searchvalue double precision, roundto double precision DEFAULT 0) returns integer
LANGUAGE SQL
AS $$
SELECT ( public._ST_valuecount($1, $2, TRUE, ARRAY[$3]::double precision[], $4)).count
$$;
