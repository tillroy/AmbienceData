create function st_overlaps(geom1 geometry, geom2 geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Overlaps($1,$2)
$$;
