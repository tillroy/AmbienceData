create function st_multilinestringfromtext(text) returns geometry
LANGUAGE SQL
AS $$
SELECT public.ST_MLineFromText($1)
$$;
