create function st_tile(rast raster, nband integer[], width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision) returns SETOF raster
LANGUAGE SQL
AS $$
SELECT public._ST_tile($1, $3, $4, $2, $5, $6)
$$;
