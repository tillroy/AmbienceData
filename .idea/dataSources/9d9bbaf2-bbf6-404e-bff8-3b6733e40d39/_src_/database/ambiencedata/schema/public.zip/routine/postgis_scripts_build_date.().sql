create function postgis_scripts_build_date() returns text
LANGUAGE SQL
AS $$
SELECT '2017-02-02 14:41:07'::text AS version
$$;
