create function st_askml(geog geography, maxdecimaldigits integer DEFAULT 15) returns text
LANGUAGE SQL
AS $$
SELECT public._ST_AsKML(2, $1, $2, null)
$$;
