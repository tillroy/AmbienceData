create function st_addband(rast raster, pixeltype text, initialvalue double precision DEFAULT '0'::numeric, nodataval double precision DEFAULT NULL::double precision) returns raster
LANGUAGE SQL
AS $$
SELECT  public.ST_addband($1, ARRAY[ROW(NULL, $2, $3, $4)]::addbandarg[])
$$;
