create function overlaps_geog(geography, gidx) returns boolean
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&) $1;
$$;
